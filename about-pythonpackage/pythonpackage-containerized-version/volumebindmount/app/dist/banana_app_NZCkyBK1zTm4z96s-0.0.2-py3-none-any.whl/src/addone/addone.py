def add_one(number):
    print("Adding: ",number," +1: ")
    return number + 1