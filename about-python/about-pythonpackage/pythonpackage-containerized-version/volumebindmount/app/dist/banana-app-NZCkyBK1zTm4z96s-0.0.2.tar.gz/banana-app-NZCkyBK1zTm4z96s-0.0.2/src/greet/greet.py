def SayHello():
    print("Hello from my package")
    return

if __name__ == '__main__':
    SayHello()
